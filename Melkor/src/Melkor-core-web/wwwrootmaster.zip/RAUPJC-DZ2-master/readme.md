#Pitanje 1:
~5 sekundi.

#Pitanje 2:
Na jednoj dretvi.

#Pitanje 3:
1,1588161 sekundi

#Pitanje 4:
Na 5 dretvi.

#Pitanje 5:
Parallel  calls  finished  0,2693 ms.
Sync  operation  calls  finished  0,0004 ms.
(Optimize code enabled)


