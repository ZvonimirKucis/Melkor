﻿using Zad4;

namespace Zad5
{
    public class University
    {
        public string Name { get; set; }
        public Student[] Students { get; set; }
    }
}